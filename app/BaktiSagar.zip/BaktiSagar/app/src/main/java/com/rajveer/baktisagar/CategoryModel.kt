package com.rajveer.baktisagar

import java.net.URL

data class CategoryModel(
    val name: String,
    val coverURL: String,
){
    constructor():this("","")
}


